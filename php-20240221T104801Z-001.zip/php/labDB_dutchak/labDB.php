<?php
    require '../config.php';
?>

<html>
    <head>
        <title>lab_DB</title>
    </head>
    <body>
        <ul>

            <li>
                <a href="task1-3.php">
                    <p>Task 1-3</p>
                </a>
            </li>

            <li>
                <a href="task4.php">
                    <p>Task 4</p>
                </a>
            </li>

            <li>
                <a href="task5-6.php">
                    <p>Task 5-6</p>
                </a>
            </li>
        </ul>
    </body>
</html>

